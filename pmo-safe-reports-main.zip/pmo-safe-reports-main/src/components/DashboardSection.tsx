import { Shield, DollarSign, FileText, Wrench, AlertTriangle, CheckCircle } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

const stats = [
  { label: "حوادث هذا الشهر", value: "3", icon: AlertTriangle, color: "text-destructive" },
  { label: "فحوصات مكتملة", value: "28", icon: CheckCircle, color: "text-success" },
  { label: "إجمالي الحراس", value: "45", icon: Shield, color: "text-primary" },
  { label: "طلبات صيانة", value: "12", icon: Wrench, color: "text-accent" },
];

const DashboardSection = () => {
  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-bold text-foreground">لوحة التحكم</h2>
        <p className="text-muted-foreground mt-1">نظرة عامة على جميع الأقسام</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, i) => {
          const Icon = stat.icon;
          return (
            <Card key={i} className="border-none shadow-md hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">{stat.label}</p>
                    <p className="text-3xl font-bold mt-2 text-foreground">{stat.value}</p>
                  </div>
                  <div className={`p-3 rounded-xl bg-muted ${stat.color}`}>
                    <Icon size={24} />
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="border-none shadow-md">
          <CardContent className="p-6">
            <h3 className="font-semibold text-lg mb-4 text-foreground">آخر الحوادث</h3>
            <div className="space-y-3">
              {[
                { text: "سقوط عامل من ارتفاع - الموقع A", date: "2026-04-03", severity: "عالي" },
                { text: "إصابة يد - ورشة الصيانة", date: "2026-04-01", severity: "متوسط" },
                { text: "انزلاق في الممر الرئيسي", date: "2026-03-28", severity: "منخفض" },
              ].map((item, i) => (
                <div key={i} className="flex items-center justify-between p-3 bg-muted rounded-lg">
                  <div>
                    <p className="text-sm font-medium text-foreground">{item.text}</p>
                    <p className="text-xs text-muted-foreground">{item.date}</p>
                  </div>
                  <span className={`text-xs px-2 py-1 rounded-full font-medium ${
                    item.severity === "عالي" ? "bg-destructive/10 text-destructive" :
                    item.severity === "متوسط" ? "bg-warning/10 text-warning" :
                    "bg-success/10 text-success"
                  }`}>
                    {item.severity}
                  </span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="border-none shadow-md">
          <CardContent className="p-6">
            <h3 className="font-semibold text-lg mb-4 text-foreground">طلبات الصيانة الأخيرة</h3>
            <div className="space-y-3">
              {[
                { text: "إصلاح مكيف - المبنى 3", status: "قيد التنفيذ" },
                { text: "صيانة مصعد - المبنى 1", status: "مكتمل" },
                { text: "تسرب مياه - الطابق 2", status: "جديد" },
              ].map((item, i) => (
                <div key={i} className="flex items-center justify-between p-3 bg-muted rounded-lg">
                  <p className="text-sm font-medium text-foreground">{item.text}</p>
                  <span className={`text-xs px-2 py-1 rounded-full font-medium ${
                    item.status === "مكتمل" ? "bg-success/10 text-success" :
                    item.status === "قيد التنفيذ" ? "bg-primary/10 text-primary" :
                    "bg-accent/10 text-accent"
                  }`}>
                    {item.status}
                  </span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default DashboardSection;
