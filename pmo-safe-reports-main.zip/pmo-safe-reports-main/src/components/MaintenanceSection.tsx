import { useState, useRef } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Clock, CheckCircle, AlertCircle, Download, Camera, Image, X, Eye } from "lucide-react";

interface MaintenanceRequest {
  id: number;
  title: string;
  description: string;
  location: string;
  priority: string;
  status: string;
  date: string;
  assignedTo: string;
  beforeImages: string[];
  afterImages: string[];
}

const MaintenanceSection = () => {
  const [requests, setRequests] = useState<MaintenanceRequest[]>([
    { id: 1, title: "إصلاح مكيف مركزي", description: "المكيف لا يعمل بشكل صحيح", location: "المبنى 3 - الطابق 2", priority: "عالي", status: "قيد التنفيذ", date: "2026-04-03", assignedTo: "فريق التكييف", beforeImages: [], afterImages: [] },
    { id: 2, title: "صيانة مصعد", description: "صوت غير طبيعي عند التشغيل", location: "المبنى 1", priority: "عالي", status: "مكتمل", date: "2026-04-01", assignedTo: "شركة المصاعد", beforeImages: [], afterImages: [] },
    { id: 3, title: "تسرب مياه", description: "تسرب من السقف", location: "المبنى 2 - الطابق 3", priority: "متوسط", status: "جديد", date: "2026-04-04", assignedTo: "فريق السباكة", beforeImages: [], afterImages: [] },
    { id: 4, title: "إصلاح إضاءة", description: "إضاءة الممر لا تعمل", location: "المبنى 1 - الطابق 1", priority: "منخفض", status: "جديد", date: "2026-04-04", assignedTo: "فريق الكهرباء", beforeImages: [], afterImages: [] },
  ]);
  const [showForm, setShowForm] = useState(false);
  const [filter, setFilter] = useState("الكل");
  const [form, setForm] = useState({ title: "", description: "", location: "", priority: "", assignedTo: "" });
  const [formBeforeImages, setFormBeforeImages] = useState<string[]>([]);
  const [expandedId, setExpandedId] = useState<number | null>(null);
  const [viewImage, setViewImage] = useState<string | null>(null);
  const beforeInputRef = useRef<HTMLInputElement>(null);
  const afterInputRefs = useRef<Record<number, HTMLInputElement | null>>({});

  const handleFileUpload = (files: FileList | null, callback: (urls: string[]) => void, existing: string[] = []) => {
    if (!files) return;
    const newUrls: string[] = [];
    Array.from(files).forEach((file) => {
      const url = URL.createObjectURL(file);
      newUrls.push(url);
    });
    callback([...existing, ...newUrls]);
  };

  const handleAdd = () => {
    if (!form.title || !form.priority) return;
    setRequests([...requests, {
      ...form,
      id: Date.now(),
      status: "جديد",
      date: new Date().toISOString().split("T")[0],
      beforeImages: formBeforeImages,
      afterImages: [],
    }]);
    setForm({ title: "", description: "", location: "", priority: "", assignedTo: "" });
    setFormBeforeImages([]);
    setShowForm(false);
  };

  const updateStatus = (id: number, status: string) => {
    setRequests(requests.map((r) => r.id === id ? { ...r, status } : r));
  };

  const addAfterImages = (id: number, files: FileList | null) => {
    if (!files) return;
    const newUrls = Array.from(files).map((f) => URL.createObjectURL(f));
    setRequests(requests.map((r) => r.id === id ? { ...r, afterImages: [...r.afterImages, ...newUrls] } : r));
  };

  const removeImage = (reqId: number, type: "before" | "after", index: number) => {
    setRequests(requests.map((r) => {
      if (r.id !== reqId) return r;
      const key = type === "before" ? "beforeImages" : "afterImages";
      return { ...r, [key]: r[key].filter((_, i) => i !== index) };
    }));
  };

  const exportCSV = () => {
    const headers = ["العنوان", "الوصف", "الموقع", "الأولوية", "الحالة", "التاريخ", "مسند إلى"];
    const rows = requests.map((r) => [r.title, r.description, r.location, r.priority, r.status, r.date, r.assignedTo]);
    const csv = "\uFEFF" + [headers, ...rows].map((row) => row.map((c) => `"${c}"`).join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = `تقرير_الصيانة_${new Date().toISOString().split("T")[0]}.csv`;
    link.click();
  };

  const filtered = filter === "الكل" ? requests : requests.filter((r) => r.status === filter);

  const statusIcon = (status: string) => {
    if (status === "مكتمل") return <CheckCircle size={16} className="text-success" />;
    if (status === "قيد التنفيذ") return <Clock size={16} className="text-primary" />;
    return <AlertCircle size={16} className="text-accent" />;
  };

  return (
    <div className="space-y-8">
      {/* Image Viewer Modal */}
      {viewImage && (
        <div className="fixed inset-0 bg-foreground/80 z-50 flex items-center justify-center p-4" onClick={() => setViewImage(null)}>
          <div className="relative max-w-4xl max-h-[90vh]">
            <button onClick={() => setViewImage(null)} className="absolute -top-10 left-0 text-card p-1">
              <X size={24} />
            </button>
            <img src={viewImage} alt="عرض الصورة" className="max-w-full max-h-[85vh] rounded-lg object-contain" />
          </div>
        </div>
      )}

      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-2xl font-bold text-foreground">الصيانة</h2>
          <p className="text-muted-foreground mt-1">إدارة طلبات الصيانة ومتابعتها</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={exportCSV} className="gap-2">
            <Download size={18} />
            تصدير
          </Button>
          <Button onClick={() => setShowForm(!showForm)} className="gap-2">
            <Plus size={18} />
            طلب صيانة جديد
          </Button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Card className="border-none shadow-md">
          <CardContent className="p-5 flex items-center gap-4">
            <div className="p-3 rounded-xl bg-accent/10">
              <AlertCircle size={24} className="text-accent" />
            </div>
            <div>
              <p className="text-2xl font-bold text-foreground">{requests.filter((r) => r.status === "جديد").length}</p>
              <p className="text-sm text-muted-foreground">طلبات جديدة</p>
            </div>
          </CardContent>
        </Card>
        <Card className="border-none shadow-md">
          <CardContent className="p-5 flex items-center gap-4">
            <div className="p-3 rounded-xl bg-primary/10">
              <Clock size={24} className="text-primary" />
            </div>
            <div>
              <p className="text-2xl font-bold text-foreground">{requests.filter((r) => r.status === "قيد التنفيذ").length}</p>
              <p className="text-sm text-muted-foreground">قيد التنفيذ</p>
            </div>
          </CardContent>
        </Card>
        <Card className="border-none shadow-md">
          <CardContent className="p-5 flex items-center gap-4">
            <div className="p-3 rounded-xl bg-success/10">
              <CheckCircle size={24} className="text-success" />
            </div>
            <div>
              <p className="text-2xl font-bold text-foreground">{requests.filter((r) => r.status === "مكتمل").length}</p>
              <p className="text-sm text-muted-foreground">مكتملة</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {showForm && (
        <Card className="border-none shadow-md">
          <CardContent className="p-6 space-y-4">
            <h3 className="font-semibold text-lg text-foreground">طلب صيانة جديد</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Input placeholder="عنوان الطلب" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
              <Input placeholder="الموقع" value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} />
              <Select value={form.priority} onValueChange={(v) => setForm({ ...form, priority: v })}>
                <SelectTrigger><SelectValue placeholder="الأولوية" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="عالي">عالي</SelectItem>
                  <SelectItem value="متوسط">متوسط</SelectItem>
                  <SelectItem value="منخفض">منخفض</SelectItem>
                </SelectContent>
              </Select>
              <Input placeholder="مسند إلى" value={form.assignedTo} onChange={(e) => setForm({ ...form, assignedTo: e.target.value })} />
            </div>
            <Textarea placeholder="وصف المشكلة" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />

            {/* Before images upload */}
            <div>
              <p className="text-sm font-medium text-foreground mb-2 flex items-center gap-2">
                <Camera size={16} className="text-primary" />
                صور قبل الإجراء
              </p>
              <input
                ref={beforeInputRef}
                type="file"
                accept="image/*"
                multiple
                className="hidden"
                onChange={(e) => handleFileUpload(e.target.files, setFormBeforeImages, formBeforeImages)}
              />
              <div className="flex flex-wrap gap-3">
                {formBeforeImages.map((img, i) => (
                  <div key={i} className="relative group">
                    <img src={img} alt="قبل" className="w-20 h-20 object-cover rounded-lg border border-border" />
                    <button
                      onClick={() => setFormBeforeImages(formBeforeImages.filter((_, idx) => idx !== i))}
                      className="absolute -top-2 -left-2 bg-destructive text-destructive-foreground rounded-full w-5 h-5 flex items-center justify-center text-xs opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <X size={12} />
                    </button>
                  </div>
                ))}
                <button
                  onClick={() => beforeInputRef.current?.click()}
                  className="w-20 h-20 rounded-lg border-2 border-dashed border-border flex flex-col items-center justify-center text-muted-foreground hover:border-primary hover:text-primary transition-colors"
                >
                  <Image size={20} />
                  <span className="text-xs mt-1">إضافة</span>
                </button>
              </div>
            </div>

            <div className="flex gap-2">
              <Button onClick={handleAdd}>حفظ</Button>
              <Button variant="outline" onClick={() => setShowForm(false)}>إلغاء</Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Filter */}
      <div className="flex gap-2 flex-wrap">
        {["الكل", "جديد", "قيد التنفيذ", "مكتمل"].map((f) => (
          <Button
            key={f}
            variant={filter === f ? "default" : "outline"}
            size="sm"
            onClick={() => setFilter(f)}
          >
            {f}
          </Button>
        ))}
      </div>

      {/* Requests */}
      <div className="space-y-3">
        {filtered.map((req) => (
          <Card key={req.id} className="border-none shadow-sm hover:shadow-md transition-shadow">
            <CardContent className="p-5">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1 flex-wrap">
                    {statusIcon(req.status)}
                    <p className="font-medium text-foreground">{req.title}</p>
                    <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${
                      req.priority === "عالي" ? "bg-destructive/10 text-destructive" :
                      req.priority === "متوسط" ? "bg-warning/10 text-warning" :
                      "bg-muted text-muted-foreground"
                    }`}>
                      {req.priority}
                    </span>
                    {(req.beforeImages.length > 0 || req.afterImages.length > 0) && (
                      <button
                        onClick={() => setExpandedId(expandedId === req.id ? null : req.id)}
                        className="text-xs text-primary flex items-center gap-1 hover:underline"
                      >
                        <Eye size={14} />
                        صور ({req.beforeImages.length + req.afterImages.length})
                      </button>
                    )}
                  </div>
                  <p className="text-sm text-muted-foreground">{req.description}</p>
                  <p className="text-xs text-muted-foreground mt-2">📍 {req.location} • 👷 {req.assignedTo} • 📅 {req.date}</p>
                </div>
                <div className="flex gap-1 mr-4 flex-wrap">
                  {req.status !== "قيد التنفيذ" && req.status !== "مكتمل" && (
                    <Button size="sm" variant="outline" onClick={() => updateStatus(req.id, "قيد التنفيذ")}>
                      بدء العمل
                    </Button>
                  )}
                  {req.status === "قيد التنفيذ" && (
                    <Button size="sm" onClick={() => updateStatus(req.id, "مكتمل")}>
                      إنهاء
                    </Button>
                  )}
                  <input
                    ref={(el) => { afterInputRefs.current[req.id] = el; }}
                    type="file"
                    accept="image/*"
                    multiple
                    className="hidden"
                    onChange={(e) => addAfterImages(req.id, e.target.files)}
                  />
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => afterInputRefs.current[req.id]?.click()}
                    title="إضافة صور"
                  >
                    <Camera size={16} />
                  </Button>
                </div>
              </div>

              {/* Expanded images */}
              {expandedId === req.id && (
                <div className="mt-4 pt-4 border-t border-border space-y-4">
                  {req.beforeImages.length > 0 && (
                    <div>
                      <p className="text-sm font-medium text-foreground mb-2 flex items-center gap-2">
                        <span className="bg-destructive/10 text-destructive text-xs px-2 py-0.5 rounded-full">قبل</span>
                      </p>
                      <div className="flex flex-wrap gap-2">
                        {req.beforeImages.map((img, i) => (
                          <div key={i} className="relative group">
                            <img
                              src={img}
                              alt="قبل"
                              className="w-24 h-24 object-cover rounded-lg border border-border cursor-pointer hover:opacity-80 transition-opacity"
                              onClick={() => setViewImage(img)}
                            />
                            <button
                              onClick={() => removeImage(req.id, "before", i)}
                              className="absolute -top-2 -left-2 bg-destructive text-destructive-foreground rounded-full w-5 h-5 flex items-center justify-center text-xs opacity-0 group-hover:opacity-100 transition-opacity"
                            >
                              <X size={12} />
                            </button>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                  {req.afterImages.length > 0 && (
                    <div>
                      <p className="text-sm font-medium text-foreground mb-2 flex items-center gap-2">
                        <span className="bg-success/10 text-success text-xs px-2 py-0.5 rounded-full">بعد</span>
                      </p>
                      <div className="flex flex-wrap gap-2">
                        {req.afterImages.map((img, i) => (
                          <div key={i} className="relative group">
                            <img
                              src={img}
                              alt="بعد"
                              className="w-24 h-24 object-cover rounded-lg border border-border cursor-pointer hover:opacity-80 transition-opacity"
                              onClick={() => setViewImage(img)}
                            />
                            <button
                              onClick={() => removeImage(req.id, "after", i)}
                              className="absolute -top-2 -left-2 bg-destructive text-destructive-foreground rounded-full w-5 h-5 flex items-center justify-center text-xs opacity-0 group-hover:opacity-100 transition-opacity"
                            >
                              <X size={12} />
                            </button>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                  {req.beforeImages.length === 0 && req.afterImages.length === 0 && (
                    <p className="text-sm text-muted-foreground text-center py-4">لا توجد صور مرفقة</p>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default MaintenanceSection;
