import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Shield, Plus, CheckCircle, AlertTriangle, ClipboardList } from "lucide-react";

interface Incident {
  id: number;
  title: string;
  description: string;
  date: string;
  severity: string;
  location: string;
}

const checklistItems = [
  "فحص معدات الوقاية الشخصية (PPE)",
  "فحص طفايات الحريق",
  "التأكد من سلامة المخارج",
  "فحص الإسعافات الأولية",
  "التأكد من لوحات الإرشاد",
  "فحص أنظمة الإنذار",
  "مراجعة خطة الإخلاء",
  "فحص السلالم والممرات",
];

const SafetySection = () => {
  const [incidents, setIncidents] = useState<Incident[]>([
    { id: 1, title: "سقوط عامل", description: "سقوط من ارتفاع 3 أمتار", date: "2026-04-03", severity: "عالي", location: "الموقع A" },
    { id: 2, title: "إصابة يد", description: "جرح أثناء التقطيع", date: "2026-04-01", severity: "متوسط", location: "ورشة الصيانة" },
  ]);
  const [showForm, setShowForm] = useState(false);
  const [checkedItems, setCheckedItems] = useState<boolean[]>(new Array(checklistItems.length).fill(false));
  const [form, setForm] = useState({ title: "", description: "", date: "", severity: "", location: "" });

  const handleAddIncident = () => {
    if (!form.title || !form.date || !form.severity) return;
    setIncidents([...incidents, { ...form, id: Date.now() }]);
    setForm({ title: "", description: "", date: "", severity: "", location: "" });
    setShowForm(false);
  };

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-foreground">السلامة والصحة المهنية</h2>
          <p className="text-muted-foreground mt-1">إدارة الحوادث وقوائم الفحص</p>
        </div>
        <Button onClick={() => setShowForm(!showForm)} className="gap-2">
          <Plus size={18} />
          تسجيل حادث
        </Button>
      </div>

      {showForm && (
        <Card className="border-none shadow-md">
          <CardContent className="p-6 space-y-4">
            <h3 className="font-semibold text-lg text-foreground">تسجيل حادث جديد</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Input placeholder="عنوان الحادث" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
              <Input type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} />
              <Input placeholder="الموقع" value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} />
              <Select value={form.severity} onValueChange={(v) => setForm({ ...form, severity: v })}>
                <SelectTrigger><SelectValue placeholder="درجة الخطورة" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="عالي">عالي</SelectItem>
                  <SelectItem value="متوسط">متوسط</SelectItem>
                  <SelectItem value="منخفض">منخفض</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Textarea placeholder="وصف الحادث" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
            <div className="flex gap-2">
              <Button onClick={handleAddIncident}>حفظ</Button>
              <Button variant="outline" onClick={() => setShowForm(false)}>إلغاء</Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Incidents list */}
      <div className="space-y-4">
        <h3 className="font-semibold text-lg flex items-center gap-2 text-foreground">
          <AlertTriangle size={20} className="text-destructive" />
          سجل الحوادث
        </h3>
        <div className="grid gap-3">
          {incidents.map((inc) => (
            <Card key={inc.id} className="border-none shadow-sm hover:shadow-md transition-shadow">
              <CardContent className="p-4 flex items-center justify-between">
                <div>
                  <p className="font-medium text-foreground">{inc.title}</p>
                  <p className="text-sm text-muted-foreground">{inc.description}</p>
                  <p className="text-xs text-muted-foreground mt-1">{inc.location} • {inc.date}</p>
                </div>
                <span className={`text-xs px-3 py-1 rounded-full font-medium ${
                  inc.severity === "عالي" ? "bg-destructive/10 text-destructive" :
                  inc.severity === "متوسط" ? "bg-warning/10 text-warning" :
                  "bg-success/10 text-success"
                }`}>
                  {inc.severity}
                </span>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Safety Checklist */}
      <Card className="border-none shadow-md">
        <CardContent className="p-6">
          <h3 className="font-semibold text-lg mb-4 flex items-center gap-2 text-foreground">
            <ClipboardList size={20} className="text-primary" />
            قائمة الفحص اليومية
          </h3>
          <div className="space-y-3">
            {checklistItems.map((item, i) => (
              <label key={i} className="flex items-center gap-3 p-3 rounded-lg bg-muted cursor-pointer hover:bg-muted/80 transition-colors">
                <input
                  type="checkbox"
                  checked={checkedItems[i]}
                  onChange={() => {
                    const updated = [...checkedItems];
                    updated[i] = !updated[i];
                    setCheckedItems(updated);
                  }}
                  className="w-5 h-5 rounded accent-primary"
                />
                <span className={`text-sm ${checkedItems[i] ? "line-through text-muted-foreground" : "text-foreground"}`}>
                  {item}
                </span>
              </label>
            ))}
          </div>
          <div className="mt-4 flex items-center gap-2 text-sm text-muted-foreground">
            <CheckCircle size={16} className="text-success" />
            {checkedItems.filter(Boolean).length} / {checklistItems.length} مكتمل
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default SafetySection;
