import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { FileText, Download, BarChart3, TrendingUp, TrendingDown } from "lucide-react";

const reports = [
  { title: "تقرير الحوادث الشهري", date: "أبريل 2026", type: "سلامة", count: 3, trend: "down" },
  { title: "تقرير رواتب الحراس", date: "أبريل 2026", type: "مالي", count: 45, trend: "up" },
  { title: "تقرير الصيانة الدورية", date: "أبريل 2026", type: "صيانة", count: 12, trend: "up" },
  { title: "تقرير الفحوصات الأمنية", date: "مارس 2026", type: "سلامة", count: 28, trend: "down" },
  { title: "تقرير المصاريف الشهري", date: "مارس 2026", type: "مالي", count: 0, trend: "up" },
];

const monthlyStats = [
  { month: "يناير", incidents: 5, maintenance: 8 },
  { month: "فبراير", incidents: 3, maintenance: 10 },
  { month: "مارس", incidents: 4, maintenance: 7 },
  { month: "أبريل", incidents: 3, maintenance: 12 },
];

const ReportsSection = () => {
  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-bold text-foreground">التقارير</h2>
        <p className="text-muted-foreground mt-1">تقارير شاملة لجميع الأقسام</p>
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Card className="border-none shadow-md">
          <CardContent className="p-6 text-center">
            <BarChart3 size={32} className="mx-auto text-primary mb-2" />
            <p className="text-3xl font-bold text-foreground">5</p>
            <p className="text-sm text-muted-foreground">تقارير هذا الشهر</p>
          </CardContent>
        </Card>
        <Card className="border-none shadow-md">
          <CardContent className="p-6 text-center">
            <TrendingDown size={32} className="mx-auto text-success mb-2" />
            <p className="text-3xl font-bold text-foreground">-25%</p>
            <p className="text-sm text-muted-foreground">انخفاض الحوادث</p>
          </CardContent>
        </Card>
        <Card className="border-none shadow-md">
          <CardContent className="p-6 text-center">
            <TrendingUp size={32} className="mx-auto text-primary mb-2" />
            <p className="text-3xl font-bold text-foreground">92%</p>
            <p className="text-sm text-muted-foreground">نسبة إنجاز الصيانة</p>
          </CardContent>
        </Card>
      </div>

      {/* Monthly stats table */}
      <Card className="border-none shadow-md">
        <CardContent className="p-6">
          <h3 className="font-semibold text-lg mb-4 text-foreground">الإحصائيات الشهرية</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-muted">
                  <th className="text-right p-3 font-semibold text-foreground">الشهر</th>
                  <th className="text-right p-3 font-semibold text-foreground">الحوادث</th>
                  <th className="text-right p-3 font-semibold text-foreground">طلبات الصيانة</th>
                </tr>
              </thead>
              <tbody>
                {monthlyStats.map((row, i) => (
                  <tr key={i} className="border-t border-border">
                    <td className="p-3 font-medium text-foreground">{row.month}</td>
                    <td className="p-3 text-destructive">{row.incidents}</td>
                    <td className="p-3 text-primary">{row.maintenance}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Reports list */}
      <div className="space-y-3">
        <h3 className="font-semibold text-lg text-foreground">قائمة التقارير</h3>
        {reports.map((report, i) => (
          <Card key={i} className="border-none shadow-sm hover:shadow-md transition-shadow">
            <CardContent className="p-4 flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="p-2 rounded-lg bg-primary/10">
                  <FileText size={20} className="text-primary" />
                </div>
                <div>
                  <p className="font-medium text-foreground">{report.title}</p>
                  <p className="text-xs text-muted-foreground">{report.date} • {report.type}</p>
                </div>
              </div>
              <Button variant="outline" size="sm" className="gap-2">
                <Download size={14} />
                تحميل
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default ReportsSection;
