import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { DollarSign, Calculator, Plus, Trash2, Download } from "lucide-react";

interface Guard {
  id: number;
  name: string;
  baseSalary: number;
  overtime: number;
  deductions: number;
  allowances: number;
}

const SalariesSection = () => {
  const [guards, setGuards] = useState<Guard[]>([
    { id: 1, name: "أحمد محمد", baseSalary: 4000, overtime: 500, deductions: 200, allowances: 600 },
    { id: 2, name: "خالد عبدالله", baseSalary: 3800, overtime: 300, deductions: 0, allowances: 500 },
    { id: 3, name: "سعيد العمري", baseSalary: 4200, overtime: 700, deductions: 150, allowances: 600 },
  ]);
  const [form, setForm] = useState({ name: "", baseSalary: "", overtime: "", deductions: "", allowances: "" });
  const [showForm, setShowForm] = useState(false);

  const calcNet = (g: Guard) => g.baseSalary + g.overtime + g.allowances - g.deductions;
  const totalSalaries = guards.reduce((sum, g) => sum + calcNet(g), 0);

  const handleAdd = () => {
    if (!form.name || !form.baseSalary) return;
    setGuards([...guards, {
      id: Date.now(),
      name: form.name,
      baseSalary: Number(form.baseSalary),
      overtime: Number(form.overtime) || 0,
      deductions: Number(form.deductions) || 0,
      allowances: Number(form.allowances) || 0,
    }]);
    setForm({ name: "", baseSalary: "", overtime: "", deductions: "", allowances: "" });
    setShowForm(false);
  };

  const exportCSV = () => {
    const headers = ["الاسم", "الراتب الأساسي", "إضافي", "بدلات", "خصومات", "الصافي"];
    const rows = guards.map((g) => [g.name, g.baseSalary, g.overtime, g.allowances, g.deductions, calcNet(g)]);
    const csv = "\uFEFF" + [headers, ...rows].map((row) => row.map((c) => `"${c}"`).join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = `رواتب_الحراس_${new Date().toISOString().split("T")[0]}.csv`;
    link.click();
  };

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-2xl font-bold text-foreground">رواتب الحراس</h2>
          <p className="text-muted-foreground mt-1">حساب وإدارة رواتب الحراس</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={exportCSV} className="gap-2">
            <Download size={18} />
            تصدير
          </Button>
          <Button onClick={() => setShowForm(!showForm)} className="gap-2">
            <Plus size={18} />
            إضافة حارس
          </Button>
        </div>
      </div>

      {/* Total */}
      <Card className="border-none shadow-md bg-primary text-primary-foreground">
        <CardContent className="p-6 flex items-center justify-between">
          <div>
            <p className="text-sm opacity-80">إجمالي الرواتب الشهرية</p>
            <p className="text-3xl font-bold mt-1">{totalSalaries.toLocaleString()} ر.س</p>
          </div>
          <div className="bg-primary-foreground/20 p-3 rounded-xl">
            <Calculator size={28} />
          </div>
        </CardContent>
      </Card>

      {showForm && (
        <Card className="border-none shadow-md">
          <CardContent className="p-6 space-y-4">
            <h3 className="font-semibold text-lg text-foreground">إضافة حارس جديد</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <Input placeholder="اسم الحارس" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
              <Input type="number" placeholder="الراتب الأساسي" value={form.baseSalary} onChange={(e) => setForm({ ...form, baseSalary: e.target.value })} />
              <Input type="number" placeholder="ساعات إضافية" value={form.overtime} onChange={(e) => setForm({ ...form, overtime: e.target.value })} />
              <Input type="number" placeholder="الخصومات" value={form.deductions} onChange={(e) => setForm({ ...form, deductions: e.target.value })} />
              <Input type="number" placeholder="البدلات" value={form.allowances} onChange={(e) => setForm({ ...form, allowances: e.target.value })} />
            </div>
            <div className="flex gap-2">
              <Button onClick={handleAdd}>حفظ</Button>
              <Button variant="outline" onClick={() => setShowForm(false)}>إلغاء</Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Guards table */}
      <Card className="border-none shadow-md overflow-hidden">
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-muted">
                  <th className="text-right p-4 font-semibold text-foreground">الاسم</th>
                  <th className="text-right p-4 font-semibold text-foreground">الراتب الأساسي</th>
                  <th className="text-right p-4 font-semibold text-foreground">إضافي</th>
                  <th className="text-right p-4 font-semibold text-foreground">بدلات</th>
                  <th className="text-right p-4 font-semibold text-foreground">خصومات</th>
                  <th className="text-right p-4 font-semibold text-foreground">الصافي</th>
                  <th className="p-4"></th>
                </tr>
              </thead>
              <tbody>
                {guards.map((g) => (
                  <tr key={g.id} className="border-t border-border hover:bg-muted/50 transition-colors">
                    <td className="p-4 font-medium text-foreground">{g.name}</td>
                    <td className="p-4 text-muted-foreground">{g.baseSalary.toLocaleString()}</td>
                    <td className="p-4 text-success">{g.overtime.toLocaleString()}</td>
                    <td className="p-4 text-primary">{g.allowances.toLocaleString()}</td>
                    <td className="p-4 text-destructive">{g.deductions.toLocaleString()}</td>
                    <td className="p-4 font-bold text-foreground">{calcNet(g).toLocaleString()} ر.س</td>
                    <td className="p-4">
                      <button
                        onClick={() => setGuards(guards.filter((x) => x.id !== g.id))}
                        className="text-destructive/60 hover:text-destructive transition-colors"
                      >
                        <Trash2 size={16} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default SalariesSection;
