import { useState } from "react";
import {
  Shield,
  DollarSign,
  FileText,
  Wrench,
  LayoutDashboard,
  Menu,
  X,
  HardHat,
} from "lucide-react";

type Section = "dashboard" | "safety" | "salaries" | "reports" | "maintenance";

interface AppSidebarProps {
  active: Section;
  onNavigate: (section: Section) => void;
}

const navItems: { id: Section; label: string; icon: React.ElementType }[] = [
  { id: "dashboard", label: "لوحة التحكم", icon: LayoutDashboard },
  { id: "safety", label: "السلامة والصحة المهنية", icon: Shield },
  { id: "salaries", label: "رواتب الحراس", icon: DollarSign },
  { id: "reports", label: "التقارير", icon: FileText },
  { id: "maintenance", label: "الصيانة", icon: Wrench },
];

const AppSidebar = ({ active, onNavigate }: AppSidebarProps) => {
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <>
      {/* Mobile toggle */}
      <button
        className="fixed top-4 right-4 z-50 md:hidden bg-primary text-primary-foreground p-2 rounded-lg shadow-lg"
        onClick={() => setMobileOpen(!mobileOpen)}
      >
        {mobileOpen ? <X size={24} /> : <Menu size={24} />}
      </button>

      {/* Overlay */}
      {mobileOpen && (
        <div
          className="fixed inset-0 bg-foreground/40 z-30 md:hidden"
          onClick={() => setMobileOpen(false)}
        />
      )}

      <aside
        className={`fixed top-0 right-0 h-full w-72 bg-sidebar-bg text-sidebar-fg z-40 transform transition-transform duration-300 md:translate-x-0 ${
          mobileOpen ? "translate-x-0" : "translate-x-full md:translate-x-0"
        }`}
      >
        {/* Logo */}
        <div className="flex items-center gap-3 p-6 border-b border-sidebar-fg/10">
          <div className="bg-accent p-2 rounded-lg">
            <HardHat size={28} className="text-accent-foreground" />
          </div>
          <div>
            <h1 className="text-lg font-bold">نظام السلامة</h1>
            <p className="text-xs text-sidebar-fg/60">PMO Group</p>
          </div>
        </div>

        {/* Nav */}
        <nav className="p-4 space-y-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = active === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  onNavigate(item.id);
                  setMobileOpen(false);
                }}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-all ${
                  isActive
                    ? "bg-accent text-accent-foreground shadow-md"
                    : "text-sidebar-fg/80 hover:bg-sidebar-fg/10"
                }`}
              >
                <Icon size={20} />
                {item.label}
              </button>
            );
          })}
        </nav>
      </aside>
    </>
  );
};

export default AppSidebar;
export type { Section };
