import { useState } from "react";
import AppSidebar, { type Section } from "@/components/AppSidebar";
import DashboardSection from "@/components/DashboardSection";
import SafetySection from "@/components/SafetySection";
import SalariesSection from "@/components/SalariesSection";
import ReportsSection from "@/components/ReportsSection";
import MaintenanceSection from "@/components/MaintenanceSection";

const Index = () => {
  const [activeSection, setActiveSection] = useState<Section>("dashboard");

  const renderSection = () => {
    switch (activeSection) {
      case "dashboard": return <DashboardSection />;
      case "safety": return <SafetySection />;
      case "salaries": return <SalariesSection />;
      case "reports": return <ReportsSection />;
      case "maintenance": return <MaintenanceSection />;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <AppSidebar active={activeSection} onNavigate={setActiveSection} />
      <main className="md:mr-72 p-6 md:p-10 pt-16 md:pt-10">
        {renderSection()}
      </main>
    </div>
  );
};

export default Index;
